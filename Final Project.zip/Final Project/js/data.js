let animals = [
  {
    img: "./Pictures/Akita.jpg",
    type: "Dog",
    breed: " Akita",
    color: "Color: borwn",
    birthYear: "2018",
    price: "Price: $600"
  },
  {
    img: "./Pictures/chihua.jpg",
    type: "Dog",
    breed: "chihua",
    color: "Color: White",
    birthYear: "2018",
    price: "Price: $200"
  },
  {
    img: "./Pictures/Dalmatian.jpg",
    type: "Dog",
    breed: " Dalmatian",
    color: "Color: Black & White",
    birthYear: "2018",
    price: "Price: $200"
  },
  {
    img: "./Pictures/pomerian.jpg",
    type: "Dog",
    breed: " pomerian",
    color: "Color: White",
    birthYear: "2018",
    price: "Price: $200"
  },
  {
    img: "./Pictures/lion.jpg",
    type: "Dog",
    breed: " Lion",
    color: "Color: Brown",
    birthYear: "2016",
    price: "Price: $400"
  },
  {
    img: "./Pictures/Bulldog.jpg",
    type: "Dog",
    breed: " Bulldog",
    color: "Color: Yellow ",
    birthYear: "2018",
    price: "Price: $200"
  },
  {
    img: "./Pictures/German_shepord.jpg",
    type: "Dog",
    breed: " German Shepard",
    color: "Color: Black",
    birthYear: "2018",
    price: "Price: $150"
  },
  {
    img: "./Pictures/Husky.jpg",
    type: "Dog",
    breed: " Husky",
    color: "Color: White",
    birthYear: "2016",
    price: "Price: $1200"
  },
  {
    img: "./Pictures/Labrador.jpg",
    type: "Dog",
    breed: " Labrador",
    color: "Color: Black",
    birthYear: "2018",
    price: "Price: $500"
  },
  {
    img: "./Pictures/poodle.jpeg",
    type: "Dog",
    breed: " Poodle",
    color: "Color: White",
    birthYear: "2018",
    price: "Price: $200"
  },
  {
    img: "./Pictures/Pug.jpg",
    type: "Dog",
    breed: " Pug",
    color: "Color: White",
    birthYear: "2018",
    price: "Price: $800"
  },
  {
    img: "./Pictures/Chow.jpg",
    type: "Dog",
    breed: " Chow",
    color: "Color: Brown",
    birthYear: "2018",
    price: "Price: $200"
  },
  {
    img: "./Pictures/Afga.jpeg",
    type: "Dog",
    breed: " Afga",
    color: "Color: White",
    birthYear: "2016",
    price: "Price: $1600"
  },
  {
    img: "./Pictures/Argentino.jpg",
    type: "Dog",
    breed: " Argentino",
    color: "Color: White",
    birthYear: "2018",
    price: "Price: $900"
  },
  {
    img: "./Pictures/GoldenRetriver.jpeg",
    type: "Dog",
    breed: " GoldenRetriver",
    color: "Color: White",
    birthYear: "2017",
    price: "Price: $750"
  },
  {
    img: "./Pictures/GreatDane.jpg",
    type: "Dog",
    breed: " GreatDane",
    color: "Color: Black",
    birthYear: "2017",
    price: "Price: $1900"
  },
  {
    img: "./Pictures/pug2.jpg",
    type: "Dog",
    breed: " pug2",
    color: "Color: White",
    birthYear: "2018",
    price: "Price: $600"
  }
];
console.log(animals);
